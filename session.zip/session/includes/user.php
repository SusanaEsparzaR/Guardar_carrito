<?php
include 'db.php';
class User extends DB{
    private $nombre;
    private $username;
	private $id;
	private $apellido;
	private $profesion;
	private $ciudad;
	private $telefono;
	private $edad;
	private $direccion;
	private $codigopostal;
	private $correo;
	private $contrasena;
    public function userExists($user, $pass){
		$sha1pass = sha1($pass);
        $query = $this->connect()->prepare('SELECT * FROM usuario_16 WHERE username = :user AND password = :pass');
        $query->execute(['user' => $user, 'pass' => $sha1pass]);
        if($query->rowCount()){
            return true;
        }else{
            return false;
        }
    }
    public function setUser($user){
        $query = $this->connect()->prepare('SELECT * FROM usuario_16 WHERE username = :user');
        $query->execute(['user' => $user]);
        
        foreach ($query as $currentUser) {
            $this->nombre = $currentUser['nombre'];
            $this->username = $currentUser['username'];
			$this->id = $currentUser['Id'];
			$this->apellido = $currentUser['apellido'];
			$this->profesion = $currentUser['profesion'];
			$this->ciudad = $currentUser['ciudad'];
			$this->telefono = $currentUser['telefono'];
			$this->edad = $currentUser['edad'];
			$this->direccion = $currentUser['direccion'];
			$this->codigopostal = $currentUser['codigopostal'];
			$this->correo = $currentUser['username'];
			$this->contrasena = $currentUser['password'];
        }
    }
    public function getNombre(){
        return $this->nombre;
    }
	public function getId(){
        return $this->Id;
    }
	
	public function getApellido(){
		return $this->apellido;
	}
	
	public function getProfesion(){
		return $this->profesion;
	}
	
	public function getCiudad(){
		return $this->ciudad;
	}
	
	public function getTelefono(){
		return $this->telefono;
	}
	
	public function getEdad(){
		return $this->edad;
	}
	
	public function getDireccion(){
		return $this->direccion;
	}
	
	public function getCodigoPostal(){
		return $this->codigopostal;
	}
	
	public function getCorreo(){
		return $this->correo;
	}
	
	public function getContrasena(){
		return $this->contrasena;
	}
}
?>