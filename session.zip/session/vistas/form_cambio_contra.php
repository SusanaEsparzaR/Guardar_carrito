<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Restaurar Contraseña</title>
    <link rel="shortcut icon" href="#">
    <link rel="stylesheet" href="../main.css">
</head>
<script type="text/javascript" language="javascript">

        function send_correo() {
            var correo = document.getElementById('correo').value;
            var requestBody = {
                "email": correo
                }
            URL = "http://35.167.62.109/storeutags/security/request_recovery_code";
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.open("POST", URL, false);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.send(JSON.stringify(requestBody));
            console.log(xmlhttp);
        }

        function send_codigo() {
            var correo = document.getElementById('correo').value;
            var codigo = document.getElementById('codigo').value;
            var requestBody = {
                "email": correo,
                "recovery_code": codigo
            }
            URL = "http://35.167.62.109/storeutags/security/validate_recovery_code";
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.open("POST", URL, false);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.send(JSON.stringify(requestBody));
            console.log(xmlhttp);
        }

        function send_contra() {
            var correo = document.getElementById('correo').value;
            var codigo = document.getElementById('codigo').value;
            var contrasenia = document.getElementById('password').value;
            var contrasenia2 = document.getElementById('password_confirmation').value;
            var requestBody = {
                "email": correo,
                "recovery_code": codigo,
                "password" : contrasenia,
                "password_confirmation" : contrasenia2
            }
            URL = "http://35.167.62.109/storeutags/security/update_password";
            var xmlhttp = new XMLHttpRequest();
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.open("POST", URL, false);
            xmlhttp.setRequestHeader("Content-Type", "application/json");
            xmlhttp.onreadystatechange = callbackFunction(xmlhttp);
            xmlhttp.send(JSON.stringify(requestBody));
            console.log(xmlhttp);
        }

        function callbackFunction(xmlhttp){
            alert("Respuesta recibida");
            console.log(xmlhttp.responseXML);
        }

    </script>
<body>
    <form>
        <p class="center"><h2>Restaurar contraseña</h2></p>
        <p>Validar correo: <br>
        <input type="text" name="correo" id="correo" placeholder="Ingresa tu correo" required></p>
        <p class="center">
            <input type="submit" value="Enviar correo" onBlur="send_correo();"/>
        </p>
        <br/>
        <p>Código: <br>
        <input type="text" name="codigo" id="codigo" placeholder="Ingresa tu código" ></p>
        <p class="center">
            <input type="submit" value="Validar código" onBlur="send_codigo();" />
        </p>
        <br/>
        <p>Contraseña: <br>
        <input type="password" name="password" id="password" placeholder="Ingresa tu contraseña"  minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></p>
        <p>Confirmar Contraseña: <br>
        <input type="password" name="password_confirmation" id="password_confirmation"placeholder="Confirma tu contraseña" minlength="8" pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" required></p>
    </form>
    <form action="inicio.php" method="POST"> 
        <p class="center"><input type="submit" value="Cambiar contraseña" onBlur="send_contra();"></p>
    </form>
</body>
</html>